# Getting Started

You have not started your application. Try running `shopify serve` in your project to get started
